document.write('<!-----------  footer----------->');
document.write('' +
    '<center>\n' +
    '<p style="color:#333;">© 2021-2022 TuHome</p>\n' +
    '</center>\n' +
    '');




