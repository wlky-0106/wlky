document.write('<!-----------  公共js和css start----------->');
document.write('' +
    '<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bynotes/texiao/source/css/shubiao.css">\n' +
    '<link rel="stylesheet" href="https://at.alicdn.com/t/font_2037988_gjhbcpzhs67.css" type="text/css">\n' +
//     '<script>var _hmt = _hmt || [];(function() {var hm = document.createElement("script");hm.src = "https://hm.baidu.com/hm.js?8c0854c37b23b617c441acb65529fca1";var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(hm, s);})();</script>\n' +
    '<link rel="apple-touch-icon" sizes="76x76" href="source/img/logo.png">\n' +
    '<link rel="shortcut icon" href="source/img/logo.png" type="image/x-png">\n' +
    '<link rel="stylesheet" href="source/css/mystyle.css">\n' +
    '<!--\n' +
    'Hi, It\'s TuHome. This is a good homepage theme.\n' +
    'Github: https://github.com/ye-tutu/TuHome\n' +
    'Gitee: https://gitee.com/ye-tutu/TuHome\n' +
    '-->' +
    '');





